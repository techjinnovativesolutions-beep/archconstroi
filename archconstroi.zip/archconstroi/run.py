"""
Arch Constroi – arranque do servidor
Desenvolvido por: Tech J Innovative Solutions
Uso: python run.py     (por trás do IIS via ARR -> http://127.0.0.1:8080)
"""
import os
import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=os.getenv("ARCH_HOST", "0.0.0.0"),
        port=int(os.getenv("ARCH_PORT", "8080")),
        proxy_headers=True,
        forwarded_allow_ips="*",
        log_level="info",
    )
