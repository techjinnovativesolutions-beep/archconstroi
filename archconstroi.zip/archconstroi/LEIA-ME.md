# Arch Constroi – Engenharia e Construção Civil
Website institucional + Painel Administrativo
**Desenvolvido por: Tech J Innovative Solutions**

---

## 1. Estrutura do projecto

```
archconstroi/
├── run.py                      arranque do servidor (porta 8080)
├── app/
│   ├── main.py                 rotas, WebSocket, middleware de segurança
│   ├── config.py               nome, contactos, morada, SMTP, credenciais
│   ├── db.py                   SQLite (leads, mensagens, alertas, auditoria)
│   └── security.py             hash, sanitização, rate limit, CSRF, cabeçalhos
├── templates/                  index, sobre, servicos, contactos, painel
├── static/
│   ├── css/estilo.css          preto · vermelho · branco + tema por hora do dia
│   ├── js/site.js              carrossel, lightbox, animações
│   ├── js/contactos.js         formulário + chat WebSocket do cliente
│   ├── js/painel.js            painel administrativo em tempo real
│   ├── img/                    logo, hero, history, obras, clientes
│   └── docs/                   PDFs dos projectos
└── data/archconstroi.db        base de dados (criada automaticamente)
```

## 2. Executar localmente

```bat
pip install fastapi "uvicorn[standard]" itsdangerous python-multipart jinja2
python run.py
```
Site: http://localhost:8080 · Painel: http://localhost:8080/painel

**Credenciais iniciais:** utilizador `arch` · palavra-passe `A4cc@`
(guardada apenas como hash PBKDF2-HMAC-SHA256, 260 000 iterações + salt).

Para alterar:
```bat
set ARCH_ADMIN_USER=arch
set ARCH_ADMIN_PASS=NovaSenhaForte
del data\archconstroi.db
python run.py
```

## 3. Publicação no IIS do Windows 11

O IIS não executa Python directamente — funciona como **proxy reverso** para a aplicação.

1. Instalar os módulos:
   - [URL Rewrite](https://www.iis.net/downloads/microsoft/url-rewrite)
   - [Application Request Routing (ARR)](https://www.iis.net/downloads/microsoft/application-request-routing)
2. No IIS Manager → nó do servidor → **Application Request Routing Cache** →
   *Server Proxy Settings* → marcar **Enable proxy**.
3. Criar um site apontando para a pasta `archconstroi`, com o binding do seu domínio.
4. Colocar na raiz do site o ficheiro `web.config` (já incluído neste projecto).
5. Registar a aplicação como serviço permanente (para não depender de uma consola aberta):
   ```bat
   sc create ArchConstroi binPath= "C:\caminho\python.exe C:\caminho\archconstroi\run.py" start= auto
   sc start ArchConstroi
   ```
6. Emitir o certificado HTTPS no IIS e depois, em `app/main.py`, alterar
   `secure=False` para `secure=True` na função `write_session` (cookies só por TLS).

O `web.config` incluído já encaminha WebSockets (`/ws/...`) — active também
**WebSocket Protocol** nas funcionalidades do Windows.

## 4. Segurança implementada

| Ameaça | Protecção |
|---|---|
| XSS / Javascript Injection | escape HTML em toda a entrada, CSP restritiva, `X-XSS` via CSP, sem `innerHTML` de dados brutos |
| SQL Injection | consultas 100 % parametrizadas (SQLite) |
| CSRF | token assinado por sessão, validado em todos os POST |
| Força bruta (login) | 5 tentativas / 5 min → bloqueio de 10 min + alerta crítico |
| Flood / DoS aplicacional | 240 pedidos/min por IP; 5 formulários/10 min |
| MITM | HSTS, cookies `HttpOnly` + `SameSite=Strict` (+`Secure` com TLS) |
| Clickjacking | `X-Frame-Options` e `frame-ancestors` |
| MIME sniffing | `X-Content-Type-Options: nosniff` |
| Mapeamento DNS/infra | `X-DNS-Prefetch-Control: off`, cabeçalho `Server` mascarado, docs da API desactivadas |
| Falha de autenticação | sessões assinadas com expiração de 4 h |
| Fuga de erros | qualquer excepção devolve mensagem neutra + alerta no painel |

## 5. Painel administrativo

- **Visão Geral** — KPIs, gráfico de solicitações por dia, serviços mais pedidos.
- **Solicitações** — tabela filtrável e pesquisável; mudar estado (novo / em andamento / concluído / arquivado).
- **Conversas** — chat WebSocket em tempo real com o cliente. Canais: painel, e-mail (SMTP) e SMS/chamada (links `mailto:` e `tel:` gerados automaticamente a partir dos dados do formulário).
- **Alertas & Debug** — falhas de segurança, erros de runtime e verificação de versões das dependências, com indicação da acção correctiva.
- **Auditoria** — registo de logins, bloqueios WAF e alterações de estado.
- **Sistema** — modo de manutenção (mostra “Em breve estaremos disponíveis — estamos com problemas de conexão.” em todo o site).

Para envio real de e-mail, defina antes de arrancar:
```bat
set ARCH_SMTP_HOST=smtp.oseuprovedor.com
set ARCH_SMTP_USER=email@geral.com
set ARCH_SMTP_PASS=senha
```

## 6. Personalizar

| O quê | Onde |
|---|---|
| Morada, telefone, e-mail, mapa | `app/config.py` |
| Fotografias de clientes nos depoimentos | substituir `static/img/clientes/cliente1..8.svg` |
| Textos das páginas | `templates/*.html` |
| Cores | variáveis `:root` em `static/css/estilo.css` |

## 7. Assinatura

A assinatura **Tech J Innovative Solutions** está inserida em comentário HTML no
topo de cada página — invisível no ecrã, visível apenas com `Ctrl + U`
(ver código-fonte). Aparece também no rodapé público.
