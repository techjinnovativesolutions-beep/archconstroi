"""
Arch Constroi - Camada de Segurança
Desenvolvido por: Tech J Innovative Solutions
"""
import hashlib
import hmac
import html
import os
import re
import secrets
import time
from collections import defaultdict, deque

# ---------------------------------------------------------------------------
# Hash de senha (PBKDF2-HMAC-SHA256, 260k iterações) - resistente a brute force
# ---------------------------------------------------------------------------
PBKDF2_ROUNDS = 260_000


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ROUNDS)
    return f"pbkdf2_sha256${PBKDF2_ROUNDS}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, rounds, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds)
        )
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Sanitização de entrada / saída (XSS, JS Injection, SQLi, header injection)
# ---------------------------------------------------------------------------
_DANGEROUS = re.compile(
    r"(<\s*script)|(javascript\s*:)|(on\w+\s*=)|(<\s*iframe)|(document\.cookie)"
    r"|(\bunion\b.+\bselect\b)|(--\s)|(/\*)|(\bdrop\s+table\b)|(\bor\b\s+1\s*=\s*1)",
    re.IGNORECASE | re.DOTALL,
)
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean(value: str, max_len: int = 2000) -> str:
    """Normaliza, remove controlos, corta e escapa entidades HTML."""
    if value is None:
        return ""
    value = str(value)[:max_len]
    value = _CTRL.sub("", value).strip()
    value = value.replace("\r\n", "\n")
    return html.escape(value, quote=True)


def is_malicious(value: str) -> bool:
    return bool(_DANGEROUS.search(value or ""))


EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
PHONE_RE = re.compile(r"^[+0-9 ()\-]{6,25}$")
NAME_RE = re.compile(r"^[\w\sÀ-ÿ'.\-]{3,120}$", re.UNICODE)


def validate_lead(data: dict) -> tuple[bool, str, dict]:
    """Valida o formulário de solicitação. Devolve (ok, erro, dados_limpos)."""
    out = {}
    raw_name = (data.get("nome") or "").strip()
    raw_email = (data.get("email") or "").strip()
    raw_phone = (data.get("telefone") or "").strip()
    raw_company = (data.get("empresa") or "").strip()
    raw_msg = (data.get("mensagem") or "").strip()
    raw_service = (data.get("servico") or "Geral").strip()

    for field in (raw_name, raw_email, raw_phone, raw_company, raw_msg, raw_service):
        if is_malicious(field):
            return False, "Conteúdo inválido detectado no formulário.", {}

    if not NAME_RE.match(raw_name):
        return False, "Nome completo inválido (mínimo 3 caracteres).", {}
    if not EMAIL_RE.match(raw_email) or len(raw_email) > 190:
        return False, "E-mail inválido.", {}
    if not PHONE_RE.match(raw_phone):
        return False, "Número de telefone inválido.", {}
    if len(raw_msg) < 10:
        return False, "Descreva a solicitação com pelo menos 10 caracteres.", {}

    out["nome"] = clean(raw_name, 120)
    out["email"] = clean(raw_email, 190)
    out["telefone"] = clean(raw_phone, 25)
    out["empresa"] = clean(raw_company, 140) or "—"
    out["servico"] = clean(raw_service, 80)
    out["mensagem"] = clean(raw_msg, 4000)
    return True, "", out


# ---------------------------------------------------------------------------
# Rate limiting (anti brute force / flood)
# ---------------------------------------------------------------------------
class RateLimiter:
    def __init__(self):
        self._hits: dict[str, deque] = defaultdict(deque)
        self._blocked: dict[str, float] = {}

    def check(self, key: str, limit: int, window: int, block: int = 300) -> bool:
        now = time.time()
        until = self._blocked.get(key, 0)
        if until > now:
            return False
        q = self._hits[key]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            self._blocked[key] = now + block
            q.clear()
            return False
        q.append(now)
        return True

    def reset(self, key: str) -> None:
        self._hits.pop(key, None)
        self._blocked.pop(key, None)

    def blocked_for(self, key: str) -> int:
        return max(0, int(self._blocked.get(key, 0) - time.time()))


limiter = RateLimiter()


# ---------------------------------------------------------------------------
# CSRF
# ---------------------------------------------------------------------------
def new_csrf() -> str:
    return secrets.token_urlsafe(32)


def csrf_ok(session_token: str | None, sent_token: str | None) -> bool:
    return bool(session_token) and bool(sent_token) and hmac.compare_digest(
        session_token, sent_token
    )


# ---------------------------------------------------------------------------
# Cabeçalhos de segurança (XSS, clickjacking, MITM/HSTS, sniffing, DNS)
# ---------------------------------------------------------------------------
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=(), payment=()",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Cross-Origin-Opener-Policy": "same-origin",
    "X-DNS-Prefetch-Control": "off",
    "X-Permitted-Cross-Domain-Policies": "none",
    "Content-Security-Policy": (
        "default-src 'self'; "
        "img-src 'self' data: https://maps.googleapis.com https://maps.gstatic.com; "
        "style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; "
        "connect-src 'self' ws: wss:; "
        "frame-src https://www.google.com https://maps.google.com; "
        "frame-ancestors 'self'; base-uri 'self'; form-action 'self'; "
        "object-src 'none'"
    ),
}
