"""
Arch Constroi - Camada de dados (SQLite com consultas parametrizadas)
Desenvolvido por: Tech J Innovative Solutions
"""
import os
import sqlite3
import threading
from datetime import datetime

from .security import hash_password

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "data", "archconstroi.db")
_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    empresa TEXT,
    email TEXT NOT NULL,
    telefone TEXT NOT NULL,
    servico TEXT,
    mensagem TEXT NOT NULL,
    estado TEXT NOT NULL DEFAULT 'novo',
    valor_estimado REAL DEFAULT 0,
    ip TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mensagens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL,
    autor TEXT NOT NULL,          -- 'admin' | 'cliente'
    canal TEXT NOT NULL,          -- 'painel' | 'email' | 'sms'
    corpo TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS alertas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nivel TEXT NOT NULL,          -- info | aviso | critico
    origem TEXT NOT NULL,
    titulo TEXT NOT NULL,
    detalhe TEXT NOT NULL,
    accao TEXT,
    lido INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS auditoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evento TEXT NOT NULL,
    ip TEXT,
    detalhe TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_leads_estado ON leads(estado);
CREATE INDEX IF NOT EXISTS idx_msg_lead ON mensagens(lead_id);
"""


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(admin_user: str, admin_pass: str) -> None:
    with _lock, connect() as conn:
        conn.executescript(SCHEMA)
        row = conn.execute(
            "SELECT id FROM admins WHERE username = ?", (admin_user,)
        ).fetchone()
        if not row:
            conn.execute(
                "INSERT INTO admins (username, password_hash, created_at) VALUES (?,?,?)",
                (admin_user, hash_password(admin_pass), now()),
            )
        if not conn.execute("SELECT id FROM alertas LIMIT 1").fetchone():
            conn.execute(
                """INSERT INTO alertas (nivel, origem, titulo, detalhe, accao, created_at)
                   VALUES (?,?,?,?,?,?)""",
                (
                    "info",
                    "sistema",
                    "Painel inicializado",
                    "Base de dados criada e credenciais de administração activas.",
                    "Nenhuma acção necessária.",
                    now(),
                ),
            )


def get_admin(username: str):
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM admins WHERE username = ?", (username,)
        ).fetchone()


def insert_lead(d: dict, ip: str) -> int:
    with _lock, connect() as conn:
        cur = conn.execute(
            """INSERT INTO leads (nome, empresa, email, telefone, servico, mensagem, ip, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                d["nome"], d["empresa"], d["email"], d["telefone"],
                d["servico"], d["mensagem"], ip, now(),
            ),
        )
        return cur.lastrowid


def list_leads(estado: str | None = None, q: str | None = None) -> list[sqlite3.Row]:
    sql = "SELECT * FROM leads"
    params: list = []
    where = []
    if estado and estado != "todos":
        where.append("estado = ?")
        params.append(estado)
    if q:
        where.append("(nome LIKE ? OR empresa LIKE ? OR email LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like]
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY id DESC LIMIT 300"
    with connect() as conn:
        return conn.execute(sql, params).fetchall()


def get_lead(lead_id: int):
    with connect() as conn:
        return conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()


def update_lead_state(lead_id: int, estado: str) -> None:
    with _lock, connect() as conn:
        conn.execute("UPDATE leads SET estado = ? WHERE id = ?", (estado, lead_id))


def add_message(lead_id: int, autor: str, canal: str, corpo: str) -> int:
    with _lock, connect() as conn:
        cur = conn.execute(
            """INSERT INTO mensagens (lead_id, autor, canal, corpo, created_at)
               VALUES (?,?,?,?,?)""",
            (lead_id, autor, canal, corpo, now()),
        )
        return cur.lastrowid


def list_messages(lead_id: int) -> list[sqlite3.Row]:
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM mensagens WHERE lead_id = ? ORDER BY id ASC", (lead_id,)
        ).fetchall()


def add_alert(nivel: str, origem: str, titulo: str, detalhe: str, accao: str = "") -> None:
    with _lock, connect() as conn:
        conn.execute(
            """INSERT INTO alertas (nivel, origem, titulo, detalhe, accao, created_at)
               VALUES (?,?,?,?,?,?)""",
            (nivel, origem, titulo, detalhe, accao, now()),
        )


def list_alerts(limit: int = 60) -> list[sqlite3.Row]:
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM alertas ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()


def mark_alerts_read() -> None:
    with _lock, connect() as conn:
        conn.execute("UPDATE alertas SET lido = 1")


def log_audit(evento: str, ip: str, detalhe: str = "") -> None:
    with _lock, connect() as conn:
        conn.execute(
            "INSERT INTO auditoria (evento, ip, detalhe, created_at) VALUES (?,?,?,?)",
            (evento, ip, detalhe, now()),
        )


def list_audit(limit: int = 50) -> list[sqlite3.Row]:
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM auditoria ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()


def stats() -> dict:
    with connect() as conn:
        total = conn.execute("SELECT COUNT(*) c FROM leads").fetchone()["c"]
        novos = conn.execute(
            "SELECT COUNT(*) c FROM leads WHERE estado='novo'"
        ).fetchone()["c"]
        andamento = conn.execute(
            "SELECT COUNT(*) c FROM leads WHERE estado='em_andamento'"
        ).fetchone()["c"]
        fechados = conn.execute(
            "SELECT COUNT(*) c FROM leads WHERE estado='concluido'"
        ).fetchone()["c"]
        msgs = conn.execute("SELECT COUNT(*) c FROM mensagens").fetchone()["c"]
        alerts = conn.execute(
            "SELECT COUNT(*) c FROM alertas WHERE lido=0"
        ).fetchone()["c"]
        por_servico = conn.execute(
            "SELECT servico, COUNT(*) c FROM leads GROUP BY servico ORDER BY c DESC LIMIT 6"
        ).fetchall()
        por_dia = conn.execute(
            """SELECT substr(created_at,1,10) d, COUNT(*) c FROM leads
               GROUP BY d ORDER BY d DESC LIMIT 14"""
        ).fetchall()
    conv = round((fechados / total) * 100, 1) if total else 0.0
    return {
        "total": total,
        "novos": novos,
        "andamento": andamento,
        "concluidos": fechados,
        "mensagens": msgs,
        "alertas": alerts,
        "conversao": conv,
        "por_servico": [dict(r) for r in por_servico],
        "por_dia": [dict(r) for r in reversed(por_dia)],
    }
