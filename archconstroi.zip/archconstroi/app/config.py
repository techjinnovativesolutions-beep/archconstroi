"""
Arch Constroi - Configuração central
Desenvolvido por: Tech J Innovative Solutions
"""
import os

SITE_NAME = "Arch Constroi"
SITE_FULL_NAME = "Arch Constroi – Engenharia e Construção Civil"
SIGNATURE = "Tech J Innovative Solutions"
COUNTRY = "Angola"
PHONE = "+244 924 729 664 | +244 926 199 535"
EMAIL = "conctatos@archconstroi.com"
ADDRESS = "Luanda, Angola"          # $ADDRESS — actualize aqui a morada exacta
MAPS_QUERY = "Luanda, Angola"

ADMIN_USER = os.getenv("ARCH_ADMIN_USER", "belarmino.bengue1960@gmail.com")
ADMIN_PASS = os.getenv("ARCH_ADMIN_PASS", "A4cc@")

SECRET_KEY = os.getenv("ARCH_SECRET_KEY", "")
SESSION_COOKIE = "arch_sid"
SESSION_MAX_AGE = 60 * 60 * 4       # 4 horas

# Envio automático de e-mail / SMS a partir do painel (opcional)
SMTP_HOST = os.getenv("ARCH_SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("ARCH_SMTP_PORT", "587"))
SMTP_USER = os.getenv("ARCH_SMTP_USER", "conctatos@archconstroi.com")
SMTP_PASS = os.getenv("ARCH_SMTP_PASS", "ArchConstroi@2026")
SMTP_FROM = os.getenv("ARCH_SMTP_FROM", "conctatos@archconstroi.com")

SERVICES = [
    ("projeto-arquitetura", "Projecto de Arquitectura"),
    ("construcao-civil", "Construção Civil / Empreitada"),
    ("remodelacao", "Remodelação e Acabamentos"),
    ("fit-out-comercial", "Fit-out Comercial e Retalho"),
    ("fiscalizacao", "Fiscalização e Gestão de Obra"),
    ("instalacoes", "Instalações Eléctricas e Hidráulicas"),
    ("licenciamento", "Licenciamento e Consultoria Técnica"),
    ("outro", "Outro / Parceria"),
]
