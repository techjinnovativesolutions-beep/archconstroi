"""
Arch Constroi – Engenharia e Construção Civil
Aplicação principal (FastAPI + WebSocket + SQLite)
Desenvolvido por: Tech J Innovative Solutions
"""
import asyncio
import json
import os
import secrets
import smtplib
import sys
from email.message import EmailMessage

from fastapi import Depends, FastAPI, Form, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from itsdangerous import BadSignature, URLSafeTimedSerializer
from starlette.middleware.base import BaseHTTPMiddleware

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import config as cfg
from app import db
from app.security import (
    SECURITY_HEADERS,
    clean,
    csrf_ok,
    is_malicious,
    limiter,
    new_csrf,
    validate_lead,
    verify_password,
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SECRET = cfg.SECRET_KEY or secrets.token_urlsafe(48)
signer = URLSafeTimedSerializer(SECRET, salt="arch-session")

app = FastAPI(title=cfg.SITE_FULL_NAME, docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

MAINTENANCE = {"on": False, "reason": ""}


# ---------------------------------------------------------------------------
# Middleware de segurança
# ---------------------------------------------------------------------------
class SecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        ip = client_ip(request)
        # Flood global
        if not limiter.check(f"glob:{ip}", limit=240, window=60, block=120):
            db.add_alert(
                "aviso", "waf", "Excesso de requisições bloqueado",
                f"O IP {ip} ultrapassou o limite de 240 pedidos/minuto.",
                "Verifique os registos de auditoria; considere bloquear o IP na firewall do IIS.",
            )
            return PlainTextResponse(
                "Em breve estaremos disponíveis — estamos com problemas de conexão.",
                status_code=429,
            )
        # Query string maliciosa
        if is_malicious(str(request.url.query)) or is_malicious(request.url.path):
            db.add_alert(
                "critico", "waf", "Tentativa de injecção bloqueada",
                f"IP {ip} enviou payload suspeito em {request.url.path}?{request.url.query}",
                "Payload rejeitado automaticamente. Reveja regras de WAF se for recorrente.",
            )
            db.log_audit("waf_block", ip, str(request.url))
            return PlainTextResponse(
                "Em breve estaremos disponíveis — estamos com problemas de conexão.",
                status_code=400,
            )
        if MAINTENANCE["on"] and not request.url.path.startswith(("/painel", "/static")):
            return templates.TemplateResponse(
                request=request, name="manutencao.html",
                context={"cfg": cfg, "motivo": MAINTENANCE["reason"]},
                status_code=503,
            )
        try:
            response = await call_next(request)
        except Exception as exc:  # noqa: BLE001
            db.add_alert(
                "critico", "runtime", "Erro interno na aplicação",
                f"{type(exc).__name__}: {exc} em {request.url.path}",
                "Corrigir manualmente no código-fonte indicado pelo traceback.",
            )
            return PlainTextResponse(
                "Em breve estaremos disponíveis — estamos com problemas de conexão.",
                status_code=500,
            )
        for k, v in SECURITY_HEADERS.items():
            response.headers[k] = v
        response.headers["Server"] = "ArchConstroi"
        return response


app.add_middleware(SecurityMiddleware)


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for", "")
    if fwd:
        return fwd.split(",")[0].strip()[:45]
    return request.client.host if request.client else "0.0.0.0"


# ---------------------------------------------------------------------------
# Sessões assinadas
# ---------------------------------------------------------------------------
def read_session(request: Request) -> dict:
    raw = request.cookies.get(cfg.SESSION_COOKIE)
    if not raw:
        return {}
    try:
        return signer.loads(raw, max_age=cfg.SESSION_MAX_AGE)
    except BadSignature:
        return {}
    except Exception:
        return {}


def write_session(response, data: dict) -> None:
    response.set_cookie(
        cfg.SESSION_COOKIE,
        signer.dumps(data),
        httponly=True,
        samesite="strict",
        secure=True,  # coloque True quando activar HTTPS no IIS
        max_age=cfg.SESSION_MAX_AGE,
        path="/",
    )


def require_admin(request: Request) -> dict:
    sess = read_session(request)
    if not sess.get("admin"):
        raise HTTPException(status_code=401, detail="Sessão expirada")
    return sess


def ctx(**extra) -> dict:
    base = {"cfg": cfg, "services": cfg.SERVICES}
    base.update(extra)
    return base


# ---------------------------------------------------------------------------
# WebSocket – hub de tempo real
# ---------------------------------------------------------------------------
class Hub:
    def __init__(self):
        self.admins: set[WebSocket] = set()
        self.clients: dict[int, set[WebSocket]] = {}
        self.lock = asyncio.Lock()

    async def join_admin(self, ws: WebSocket):
        async with self.lock:
            self.admins.add(ws)

    async def leave_admin(self, ws: WebSocket):
        async with self.lock:
            self.admins.discard(ws)

    async def join_client(self, lead_id: int, ws: WebSocket):
        async with self.lock:
            self.clients.setdefault(lead_id, set()).add(ws)

    async def leave_client(self, lead_id: int, ws: WebSocket):
        async with self.lock:
            self.clients.get(lead_id, set()).discard(ws)

    async def to_admins(self, payload: dict):
        dead = []
        for ws in list(self.admins):
            try:
                await ws.send_text(json.dumps(payload, ensure_ascii=False))
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.leave_admin(ws)

    async def to_client(self, lead_id: int, payload: dict):
        for ws in list(self.clients.get(lead_id, set())):
            try:
                await ws.send_text(json.dumps(payload, ensure_ascii=False))
            except Exception:
                await self.leave_client(lead_id, ws)


hub = Hub()


# ---------------------------------------------------------------------------
# Notificações automáticas (e-mail / SMS via gateway)
# ---------------------------------------------------------------------------
def send_email(to: str, subject: str, body: str) -> tuple[bool, str]:
    if not cfg.SMTP_HOST:
        return False, "SMTP não configurado (defina ARCH_SMTP_HOST). Mensagem guardada no painel."
    try:
        msg = EmailMessage()
        msg["From"] = cfg.SMTP_FROM
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)
        with smtplib.SMTP(cfg.SMTP_HOST, cfg.SMTP_PORT, timeout=15) as s:
            s.starttls()
            if cfg.SMTP_USER:
                s.login(cfg.SMTP_USER, cfg.SMTP_PASS)
            s.send_message(msg)
        return True, "E-mail entregue."
    except Exception as exc:  # noqa: BLE001
        db.add_alert("aviso", "smtp", "Falha no envio de e-mail", str(exc),
                     "Verifique as credenciais SMTP nas variáveis de ambiente.")
        return False, f"Falha SMTP: {exc}"


# ---------------------------------------------------------------------------
# Páginas públicas
# ---------------------------------------------------------------------------
def gallery(folder: str) -> list[str]:
    path = os.path.join(BASE_DIR, "static", "img", folder)
    files = sorted(
        (f for f in os.listdir(path) if f.lower().endswith((".jpeg", ".jpg", ".png"))),
        key=lambda n: (len(n), n),
    )
    return [f"/static/img/{folder}/{f}" for f in files]


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request, name="index.html", context=ctx(
            hero=gallery("hero"),
            history=gallery("history"),
            obras=gallery("obras")[:9],
            page="home"),
    )


@app.get("/sobre-nos", response_class=HTMLResponse)
async def sobre(request: Request):
    return templates.TemplateResponse(
        request=request, name="sobre.html", context=ctx( obras=gallery("obras"), page="sobre")
    )


@app.get("/nossos-servicos", response_class=HTMLResponse)
async def servicos(request: Request):
    return templates.TemplateResponse(
        request=request, name="servicos.html", context=ctx( obras=gallery("obras"), page="servicos")
    )


@app.get("/contactos", response_class=HTMLResponse)
async def contactos(request: Request):
    token = new_csrf()
    resp = templates.TemplateResponse(
        request=request, name="contactos.html", context=ctx( csrf=token, page="contactos")
    )
    sess = read_session(request)
    sess["csrf"] = token
    write_session(resp, sess)
    return resp


@app.post("/api/solicitacao")
async def nova_solicitacao(request: Request):
    ip = client_ip(request)
    if not limiter.check(f"lead:{ip}", limit=5, window=600, block=900):
        return JSONResponse(
            {"ok": False, "erro": "Demasiadas submissões. Tente novamente mais tarde."},
            status_code=429,
        )
    payload = await request.json()
    sess = read_session(request)
    if not csrf_ok(sess.get("csrf"), payload.get("csrf")):
        db.log_audit("csrf_fail", ip, "/api/solicitacao")
        return JSONResponse({"ok": False, "erro": "Sessão inválida. Recarregue a página."},
                            status_code=403)
    ok, erro, data = validate_lead(payload)
    if not ok:
        return JSONResponse({"ok": False, "erro": erro}, status_code=400)

    lead_id = db.insert_lead(data, ip)
    db.add_message(lead_id, "cliente", "painel", data["mensagem"])
    db.log_audit("nova_solicitacao", ip, f"lead #{lead_id} – {data['email']}")
    await hub.to_admins({
        "tipo": "novo_lead",
        "lead": {"id": lead_id, **data, "created_at": db.now()},
    })
    return {"ok": True, "id": lead_id,
            "mensagem": "Solicitação recebida com sucesso. A nossa equipa responde em até 24 horas úteis."}


@app.websocket("/ws/cliente/{lead_id}")
async def ws_cliente(ws: WebSocket, lead_id: int):
    await ws.accept()
    if not db.get_lead(lead_id):
        await ws.close(code=4004)
        return
    await hub.join_client(lead_id, ws)
    try:
        for m in db.list_messages(lead_id):
            await ws.send_text(json.dumps({"tipo": "historico", "msg": dict(m)}, ensure_ascii=False))
        while True:
            raw = await ws.receive_text()
            body = clean(json.loads(raw).get("corpo", ""), 2000)
            if not body:
                continue
            db.add_message(lead_id, "cliente", "painel", body)
            await hub.to_admins({"tipo": "msg_cliente", "lead_id": lead_id, "corpo": body,
                                 "created_at": db.now()})
    except WebSocketDisconnect:
        await hub.leave_client(lead_id, ws)
    except Exception:
        await hub.leave_client(lead_id, ws)


# ---------------------------------------------------------------------------
# Painel administrativo
# ---------------------------------------------------------------------------
@app.get("/painel", response_class=HTMLResponse)
async def painel_root(request: Request):
    if read_session(request).get("admin"):
        return RedirectResponse("/painel/dashboard", status_code=302)
    return RedirectResponse("/painel/login", status_code=302)


@app.get("/painel/login", response_class=HTMLResponse)
async def login_page(request: Request, erro: str = ""):
    token = new_csrf()
    resp = templates.TemplateResponse(
        request=request, name="admin_login.html", context=ctx( csrf=token, erro=clean(erro, 200))
    )
    sess = read_session(request)
    sess["csrf"] = token
    write_session(resp, sess)
    return resp


@app.post("/painel/login")
async def login_action(request: Request,
                       username: str = Form(...),
                       password: str = Form(...),
                       csrf: str = Form("")):
    ip = client_ip(request)
    if not limiter.check(f"login:{ip}", limit=5, window=300, block=600):
        segundos = limiter.blocked_for(f"login:{ip}")
        db.add_alert("critico", "auth", "Possível ataque de força bruta",
                     f"5+ tentativas falhadas de login a partir do IP {ip}.",
                     "IP bloqueado temporariamente. Considere bloqueio permanente no IIS.")
        return RedirectResponse(f"/painel/login?erro=Bloqueado por {segundos}s (força bruta)",
                                status_code=302)
    sess = read_session(request)
    if not csrf_ok(sess.get("csrf"), csrf):
        return RedirectResponse("/painel/login?erro=Sessão inválida, tente novamente", status_code=302)

    admin = db.get_admin(clean(username, 60))
    if not admin or not verify_password(password, admin["password_hash"]):
        db.log_audit("login_falhado", ip, f"user={username[:40]}")
        return RedirectResponse("/painel/login?erro=Credenciais inválidas", status_code=302)

    limiter.reset(f"login:{ip}")
    db.log_audit("login_ok", ip, f"user={admin['username']}")
    resp = RedirectResponse("/painel/dashboard", status_code=302)
    write_session(resp, {"admin": admin["username"], "csrf": new_csrf()})
    return resp


@app.get("/painel/logout")
async def logout(request: Request):
    resp = RedirectResponse("/painel/login", status_code=302)
    resp.delete_cookie(cfg.SESSION_COOKIE, path="/")
    db.log_audit("logout", client_ip(request))
    return resp


@app.get("/painel/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    sess = read_session(request)
    if not sess.get("admin"):
        return RedirectResponse("/painel/login", status_code=302)
    token = sess.get("csrf") or new_csrf()
    sess["csrf"] = token
    resp = templates.TemplateResponse(
        request=request, name="admin_dashboard.html", context=ctx(
            admin=sess["admin"],
            csrf=token,
            stats=db.stats(),
            leads=[dict(r) for r in db.list_leads()],
            alertas=[dict(r) for r in db.list_alerts()],
            auditoria=[dict(r) for r in db.list_audit()],
            manutencao=MAINTENANCE),
    )
    write_session(resp, sess)
    return resp


@app.get("/api/admin/leads")
async def api_leads(request: Request, estado: str = "todos", q: str = ""):
    require_admin(request)
    return {"leads": [dict(r) for r in db.list_leads(estado, clean(q, 60) or None)],
            "stats": db.stats()}


@app.get("/api/admin/lead/{lead_id}")
async def api_lead(request: Request, lead_id: int):
    require_admin(request)
    lead = db.get_lead(lead_id)
    if not lead:
        raise HTTPException(404, "Solicitação não encontrada")
    return {"lead": dict(lead), "mensagens": [dict(m) for m in db.list_messages(lead_id)]}


@app.post("/api/admin/lead/{lead_id}/estado")
async def api_estado(request: Request, lead_id: int):
    sess = require_admin(request)
    body = await request.json()
    if not csrf_ok(sess.get("csrf"), body.get("csrf")):
        raise HTTPException(403, "CSRF inválido")
    estado = clean(body.get("estado", ""), 20)
    if estado not in {"novo", "em_andamento", "concluido", "arquivado"}:
        raise HTTPException(400, "Estado inválido")
    db.update_lead_state(lead_id, estado)
    db.log_audit("estado_alterado", client_ip(request), f"lead #{lead_id} -> {estado}")
    return {"ok": True, "stats": db.stats()}


@app.post("/api/admin/lead/{lead_id}/responder")
async def api_responder(request: Request, lead_id: int):
    sess = require_admin(request)
    body = await request.json()
    if not csrf_ok(sess.get("csrf"), body.get("csrf")):
        raise HTTPException(403, "CSRF inválido")
    lead = db.get_lead(lead_id)
    if not lead:
        raise HTTPException(404, "Solicitação não encontrada")
    corpo = clean(body.get("corpo", ""), 4000)
    canal = clean(body.get("canal", "painel"), 10)
    if canal not in {"painel", "email", "sms"}:
        canal = "painel"
    if len(corpo) < 2:
        raise HTTPException(400, "Mensagem vazia")

    db.add_message(lead_id, "admin", canal, corpo)
    nota = "Guardado no painel."
    if canal == "email":
        ok, nota = send_email(
            lead["email"], f"{cfg.SITE_NAME} – resposta à sua solicitação #{lead_id}", corpo
        )
    elif canal == "sms":
        nota = (f"Ligação/SMS preparada para {lead['telefone']} "
                f"(tel:{lead['telefone'].replace(' ', '')}).")
    await hub.to_client(lead_id, {"tipo": "msg_admin", "corpo": corpo, "created_at": db.now()})
    await hub.to_admins({"tipo": "msg_admin", "lead_id": lead_id, "corpo": corpo,
                         "canal": canal, "created_at": db.now()})
    return {"ok": True, "nota": nota,
            "links": {"mailto": f"mailto:{lead['email']}?subject=Arch%20Constroi%20%23{lead_id}",
                      "tel": f"tel:{lead['telefone'].replace(' ', '')}"}}


@app.post("/api/admin/manutencao")
async def api_manutencao(request: Request):
    sess = require_admin(request)
    body = await request.json()
    if not csrf_ok(sess.get("csrf"), body.get("csrf")):
        raise HTTPException(403, "CSRF inválido")
    MAINTENANCE["on"] = bool(body.get("on"))
    MAINTENANCE["reason"] = clean(body.get("reason", ""), 200)
    db.log_audit("manutencao", client_ip(request), f"on={MAINTENANCE['on']}")
    return {"ok": True, "manutencao": MAINTENANCE}


@app.post("/api/admin/alertas/lidos")
async def api_alertas_lidos(request: Request):
    require_admin(request)
    db.mark_alerts_read()
    return {"ok": True}


@app.get("/api/admin/diagnostico")
async def api_diagnostico(request: Request):
    """Verifica versões das tecnologias e reporta falhas/actualizações no painel."""
    require_admin(request)
    import importlib.metadata as md
    resultados = []
    for pkg, minimo in (("fastapi", "0.110"), ("uvicorn", "0.27"), ("jinja2", "3.1"),
                        ("itsdangerous", "2.1")):
        try:
            v = md.version(pkg)
            desactualizado = v < minimo
            resultados.append({"pacote": pkg, "versao": v,
                               "estado": "actualizar" if desactualizado else "ok",
                               "minimo": minimo})
            if desactualizado:
                db.add_alert("aviso", "dependencias", f"{pkg} desactualizado",
                             f"Versão instalada {v}, mínimo recomendado {minimo}.",
                             f"Executar: pip install -U {pkg}")
        except Exception:
            resultados.append({"pacote": pkg, "versao": "—", "estado": "ausente",
                               "minimo": minimo})
    resultados.append({"pacote": "python", "versao": sys.version.split()[0],
                       "estado": "ok" if sys.version_info >= (3, 10) else "actualizar",
                       "minimo": "3.10"})
    return {"ok": True, "resultados": resultados,
            "alertas": [dict(a) for a in db.list_alerts(20)]}


@app.websocket("/ws/painel")
async def ws_painel(ws: WebSocket):
    await ws.accept()
    raw = ws.cookies.get(cfg.SESSION_COOKIE)
    try:
        sess = signer.loads(raw, max_age=cfg.SESSION_MAX_AGE) if raw else {}
    except Exception:
        sess = {}
    if not sess.get("admin"):
        await ws.close(code=4401)
        return
    await hub.join_admin(ws)
    try:
        await ws.send_text(json.dumps({"tipo": "ligado", "stats": db.stats()}, ensure_ascii=False))
        while True:
            data = json.loads(await ws.receive_text())
            if data.get("tipo") == "ping":
                await ws.send_text(json.dumps({"tipo": "pong", "stats": db.stats()},
                                              ensure_ascii=False))
            elif data.get("tipo") == "chat":
                lead_id = int(data.get("lead_id", 0))
                corpo = clean(data.get("corpo", ""), 4000)
                if lead_id and corpo:
                    db.add_message(lead_id, "admin", "painel", corpo)
                    await hub.to_client(lead_id, {"tipo": "msg_admin", "corpo": corpo,
                                                  "created_at": db.now()})
                    await hub.to_admins({"tipo": "msg_admin", "lead_id": lead_id,
                                         "corpo": corpo, "created_at": db.now()})
    except WebSocketDisconnect:
        await hub.leave_admin(ws)
    except Exception:
        await hub.leave_admin(ws)


@app.get("/robots.txt", response_class=PlainTextResponse)
async def robots():
    return "User-agent: *\nDisallow: /painel\nDisallow: /api\nAllow: /\n"


@app.on_event("startup")
async def startup():
    db.init_db(cfg.ADMIN_USER, cfg.ADMIN_PASS)
    db.add_alert("info", "sistema", "Servidor iniciado",
                 f"{cfg.SITE_FULL_NAME} em execução.", "Nenhuma acção necessária.")
